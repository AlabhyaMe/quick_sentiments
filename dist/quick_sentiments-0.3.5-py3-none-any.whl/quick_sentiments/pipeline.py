# POSITIVELY DO NOT CHANGE (This comment is for the user, I am making necessary fixes based on our conversation)

from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
from collections import Counter
from sklearn.preprocessing import LabelEncoder
import polars as pl
import importlib
import numpy as np
import pandas as pd
from typing import Union

def run_pipeline(
    vectorizer_name: str,
    model_name: str,
    df: Union[pl.DataFrame, pd.DataFrame],
    text_column_name: str,
    sentiment_column_name: str,
    perform_tuning: bool = False
):
    """
    Orchestrates the full sentiment analysis pipeline: Vectorization -> Training -> Evaluation.

    This function automatically handles data splitting, vectorization (converting text to numbers),
    training the selected machine learning model, and evaluating its performance.

    Args:
        vectorizer_name (str): 
            The method to convert text to numbers. Options:
            - 'tfidf' (Recommended for most cases)
            - 'bow' (Bag of Words - simple counts)
            - 'glove' (Word Embeddings - captures meaning)
        model_name (str): 
            The machine learning algorithm to use. Options:
            - 'rf' (Random Forest - robust)
            - 'logit' (Logistic Regression - fast baseline)
            - 'xgb' (XGBoost - high performance)
            - 'nb' (Naive Bayes - good for text)
        df (Union[pl.DataFrame, pd.DataFrame]): 
            The input DataFrame containing your data.
        text_column_name (str): 
            The name of the column containing the *cleaned* text.
        sentiment_column_name (str): 
            The name of the column containing the target labels (e.g., 'positive', 'negative').
        perform_tuning (bool, optional): 
            If True, performs Hyperparameter Tuning (GridSearch) to find the best model settings. 
            Warning: This can take a long time! Defaults to False.

    Returns:
        dict: A dictionary containing:
            - 'model_object': The trained model.
            - 'vectorizer_object': The fitted vectorizer.
            - 'accuracy': The accuracy score (float).
            - 'report': A detailed classification report.

    Example:
        >>> results = run_pipeline(
        ...     vectorizer_name="tfidf",
        ...     model_name="rf",
        ...     df=my_data,
        ...     text_column_name="clean_text",
        ...     sentiment_column_name="label"
        ... )
        >>> print(results['accuracy'])
        0.85
    """
    # --- NEW: Mapping for Short and Long Names ---
    VEC_MAP = {
        "bow": "BOW",
        "bag_of_words": "BOW",

        "tfidf": "tfidf",
        "tf_idf": "tfidf",
        "tf-idf": "tfidf",

        "tf": "tf",
        "term_frequency": "tf",

        "glove": "glove_25",
        "glove_25": "glove_25",
        "glove50": "glove_25",
        "glove_50": "glove_50",
        "glove100": "glove_100",
        "glove_100": "glove_100",
        "glove200": "glove_200",
        "glove_200": "glove_200",

        "word2vec": "wv",
        "wv": "wv",
    }

    MODEL_MAP = {
        "rf": "rf",
        "random_forest": "rf",

        "logit": "logit",
        "logistic_regression": "logit",
        "lr": "logit",

        "nb": "nb",
        "naive_bayes": "nb",

        "nn": "nn",
        "mlp": "nn",
        "neural_network": "nn",

        "xgb": "XGB",
        "xgboost": "XGB"
    }

    actual_vec_module = VEC_MAP.get(vectorizer_name.lower(), vectorizer_name)
    actual_model_module = MODEL_MAP.get(model_name.lower(), model_name)

    print(f"--- Running Pipeline for {vectorizer_name.replace('_', ' ').title()} + {model_name.replace('_', ' ').title()} ---")

    # Import vectorizer from vect folder
    try:
        vec_module = importlib.import_module(f"quick_sentiments.vect.{actual_vec_module}")
        vectorize_train = getattr(vec_module, "vectorize_train")
        vectorize_test = getattr(vec_module, "vectorize_test")
    except (ImportError, AttributeError) as e:
        print(f"Error loading vectorizer module/function: {e}")
        return None

    # Import ML model from ml_algo folder
    try:
        model_module = importlib.import_module(f"quick_sentiments.ml_algo.{actual_model_module}")
        train_and_predict_function = getattr(model_module, "train_and_predict")
    except (ImportError, AttributeError) as e:
        print(f"Error loading ML model module/function: {e}")
        return None

    """
    Modified to handle both Polars and pandas DataFrames.
    """
    # Convert to Polars if input is pandas
    if isinstance(df, pd.DataFrame):
        df = pl.from_pandas(df)
    elif not isinstance(df, pl.DataFrame):
        raise TypeError(f"Expected Polars or pandas DataFrame, got {type(df)}")
    
    # Polars DataFrame handling
    X_text = df[text_column_name].to_list()
    y_raw = df[sentiment_column_name].to_list()
    
    # --- NEW: Check for and drop None values in X_text and y_raw ---
    initial_data_len = len(X_text)
    
    # Filter out pairs where either X_text element or y_raw element is None
    # Use zip to iterate over both lists simultaneously and filter
    filtered_data = [(x, y_val) for x, y_val in zip(X_text, y_raw) if x is not None and y_val is not None]
    
    # Unzip the filtered data back into X_text and y_raw
    if filtered_data: # Check if filtered_data is not empty to avoid unpacking error
        X_text, y_raw = zip(*filtered_data)
        X_text = list(X_text) # Convert back to list
        y_raw = list(y_raw)   # Convert back to list
    else:
        # Handle case where all data might be None
        print("WARNING: All data rows contained missing values after initial extraction. Cannot proceed with training.")
        return None

    dropped_rows_count = initial_data_len - len(X_text)
    if dropped_rows_count > 0:
        print(f"WARNING: Dropped {dropped_rows_count} rows due to missing values (None) in '{text_column_name}' or '{sentiment_column_name}' columns. Original rows: {initial_data_len}, Rows after dropping: {len(X_text)}")
    else:
        print("No missing values (None) found in text or sentiment columns. Proceeding with all rows.")
    # ------------------------------------------------------------------

    # Label Encoding for y_raw
    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(y_raw)
    print(f"Labels encoded: Original -> {label_encoder.classes_}, Encoded -> {np.unique(y)}")

    # Split data Before vectorization
    print("1. Splitting data into train/test...")
    X_train, X_test, y_train, y_test = train_test_split(
        X_text, y, test_size=0.2, random_state=42, stratify=y
    )

    # Vectorize the dataset (X)
    print("2. Vectorizing  dataset (X)...")
    X_train_vectorized, fitted_vectorizer_object,norm = vectorize_train(X_train)
    X_test_vectorized = vectorize_test(X_test, fitted_vectorizer_object,norm)

    # Train + predict
    print("3. Training and predicting...")
    y_pred, trained_model_object = train_and_predict_function(X_train_vectorized, y_train, X_test_vectorized, perform_tuning=perform_tuning)

    # Evaluate
    print("4. Evaluating model...")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=label_encoder.classes_))
    print("True labels distribution:", Counter(y_test))
    print("Predicted labels distribution:", Counter(y_pred))

    # Return results including all necessary objects for future predictions
    return {
        "model_object": trained_model_object,
        "vectorizer_name": vectorizer_name,
        "vectorizer_object": fitted_vectorizer_object,
        "label_encoder": label_encoder,
        "y_test": y_test,
        "y_pred": y_pred,
        "accuracy": accuracy_score(y_test, y_pred),
        "report": classification_report(y_test, y_pred, output_dict=True, target_names=label_encoder.classes_)
    }